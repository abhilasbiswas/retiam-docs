# Retiam

Retiam is a TypeScript animation engine built on WebGPU. Write scenes for mathematical explanations, data visualizations, and 2D or 3D animation, then preview them in a browser, render video, or export an interactive web embed.

**[Documentation](https://abhilasbiswas.github.io/retiam-docs/)** · [Getting started](https://abhilasbiswas.github.io/retiam-docs/getting-started/) · [Examples](https://abhilasbiswas.github.io/retiam-docs/examples-catalog/) · [API reference](https://abhilasbiswas.github.io/retiam-docs/api-core/)

## Features

- **Scene authoring:** compose entities, groups, layouts, cameras, and interaction with TypeScript.
- **Animation and timing:** choreograph transitions with asynchronous timelines, easing, tracks, and value trackers.
- **Mathematical graphics:** create coordinate systems, plots, vector geometry, LaTeX equations, text, and highlighted code.
- **Rendering:** combine 2D paths, 3D meshes, lighting, shadows, compute effects, and post-processing.
- **Specialized libraries:** add charts, graphs, physics, procedural shapes, sketch styling, and emphasis animations through separate imports.
- **Audio and output:** work with audio, narration, and subtitles; inspect snapshots, render video, or share scenes as web components.

## Getting started

Install Retiam in your own TypeScript application:

```bash
npm install retiam
npm install --save-dev typescript vite @webgpu/types
```

Follow the [installation guide](https://abhilasbiswas.github.io/retiam-docs/installation/) for the complete project structure, TypeScript configuration, and browser entry point. To use an unpublished checkout, run `npm pack` in this repository and install the generated `.tgz` file in your application.

For Vite applications, preserve Retiam's packaged module and asset URLs by excluding it from dependency prebundling in `vite.config.ts`:

```typescript
import { defineConfig } from "vite";

export default defineConfig({
  optimizeDeps: { exclude: ["retiam"] },
});
```

Retiam requires a WebGPU-capable browser and compatible GPU. Serve browser applications over HTTPS or localhost.

### Your first scene

Save this as `scenes/FirstScene.ts`. Scenes define their animation in an asynchronous `run()` method; durations are in milliseconds.

```typescript
import { Scene, Circle, Create, FadeOut, CameraModel, hex } from "retiam";

export default class FirstScene extends Scene {
  async run() {
    this.clearColor(hex("#090E1B"));
    this.camera.model = CameraModel.ORTHOGRAPHIC;
    this.camera.orthoScale = 12;
    this.camera.position.set([0, 0, 20]);
    this.camera.lookAt([0, 0, 0]);

    const circle = new Circle(1, { fill: hex("#38BDF8") });
    circle.move([-2, 0, 0]);
    this.add(circle);

    await this.play(new Create(circle, { duration: 1200 }));
    await this.play(circle.animate.move([2, 0, 0]), { duration: 1000 });
    await this.wait(800);
    await this.play(new FadeOut(circle, { duration: 600 }));
    await this.wait(400);
  }
}
```

Start the scene from your application's browser entry point, `src/main.ts`:

```typescript
import FirstScene from "../scenes/FirstScene";

const canvas = document.querySelector<HTMLCanvasElement>("#canvas");
if (!canvas) throw new Error("Missing scene canvas.");

const scene = new FirstScene();
await scene.start(canvas);
window.addEventListener("pagehide", () => scene.destroy(), { once: true });
```

The host page needs a `<canvas id="canvas"></canvas>` with an explicit CSS display size. Continue with [your first scene](https://abhilasbiswas.github.io/retiam-docs/first-scene/) for animation, camera, and lifecycle guidance.

## CLI and video rendering

Use the CLI to analyze scenes, capture PNG snapshots, and render video:

```bash
npx retiam lint scenes/FirstScene.ts --json
npx retiam snapshot scenes/FirstScene.ts --times 1.0,2.5,4.0 --json
npx retiam render scenes/FirstScene.ts -w 1920 -h 1080 -f 60 -d 4000 -o outputs/video
```

Render and snapshot commands require the optional Puppeteer dependency and a working Chrome/WebGPU setup. Video rendering also requires FFmpeg on your `PATH`.

```bash
npm install --save-dev puppeteer
```

For rendering and snapshots, your project must include an `index.html` host that loads the scene selected by the CLI's `file` query parameter. Use the host from the [installation guide](https://abhilasbiswas.github.io/retiam-docs/installation/#create-a-consumer-application). Render duration (`-d`) is in milliseconds; output (`-o`) is a directory.

See [rendering and export](https://abhilasbiswas.github.io/retiam-docs/export/) for project setup and encoding options, or follow [package-based embeds](https://abhilasbiswas.github.io/retiam-docs/export/#embed-from-npm) to bundle a scene for another website. Run `npx retiam help` for the command reference.

## Libraries

Import shared scene primitives from `retiam` and specialized functionality from its own entry point.

| Import | Purpose |
| --- | --- |
| `retiam` | Scenes, entities, animations, cameras, geometry, text, and core math |
| `retiam/shapes` | Procedural 2D paths and 3D meshes |
| `retiam/charts` | Cartesian and polar charts, scales, themes, and tooltips |
| `retiam/graphs` | Graphs, layouts, automata, and tapes |
| `retiam/highlights` | Emphasis and attention animations |
| `retiam/physics` | 2D and 3D physics integrations |
| `retiam/rough` | Optional RoughJS styling integration |
| `retiam/tts` | Microsoft Edge speech synthesis, narration, and subtitles |

See the [library guide](https://abhilasbiswas.github.io/retiam-docs/libraries/) for import boundaries and examples. The RoughJS integration requires the optional `roughjs` peer dependency.

Built-in fonts and imported engine assets are included in the library package. Application media is managed separately. Edge speech synthesis in the browser requires a compatible service. See [asset workflows](https://abhilasbiswas.github.io/retiam-docs/asset-workflows/) and [speech and subtitles](https://abhilasbiswas.github.io/retiam-docs/speech-subtitles/) for setup.

## Repository development

Use Node.js 24, matching the documentation CI configuration.

```bash
git clone https://github.com/abhilasbiswas/Retiam.git
cd Retiam
npm ci
npm run dev
```

Open the URL printed by Vite. Retiam Studio is available at `/studio/` on the same server. See the [tooling guide](https://abhilasbiswas.github.io/retiam-docs/tooling/) for the editor, inspector, and playback controls.

### Documentation development

The viewer, authored guides, examples, assets, API reference data, and Pages workflow are maintained in the separate [retiam-docs repository](https://github.com/abhilasbiswas/retiam-docs). It installs, builds, and deploys independently of this engine checkout. See that repository's README and deployment guide for local development and publishing.

## Documentation and source

- [Handbook](https://abhilasbiswas.github.io/retiam-docs/): guides, tutorials, examples, and API references.
- [Compatibility notes](https://abhilasbiswas.github.io/retiam-docs/limitations/): current implementation boundaries and known differences from historical examples.
- [Architecture notes](docs/README.md): detailed subsystem documentation.
- [Example sources](examples/): repository scenes and integrations.
- [Agent skill](.agents/skills/retiam/SKILL.md): scene-authoring guidance for coding assistants.

